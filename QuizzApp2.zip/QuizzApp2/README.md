# Quiz Master - Android Quiz Application

A comprehensive Android quiz application built with Java that tests your knowledge across multiple categories.

## Features

### 🎯 Core Features
- **6 Quiz Categories**: Science, History, Sports, Technology, General Knowledge, and Movies
- **10 Questions per Category**: Each category contains 8-10 multiple-choice questions
- **Timer Functionality**: 20-second timer for each question
- **Question Shuffling**: Questions are randomized each time you play
- **High Score Tracking**: Persistent high score storage using SharedPreferences
- **Progress Tracking**: Visual progress bar and question counter

### 📱 User Interface
- **Splash Screen**: App logo with brief loading animation
- **Main Menu**: Category selection with clean card-based design
- **Quiz Screen**: Interactive question display with radio button options
- **Result Screen**: Detailed score breakdown with performance feedback

### 🎨 Design Features
- **Material Design**: Modern UI following Material Design principles
- **Responsive Layout**: Works on different screen sizes
- **Color-coded Feedback**: Visual indicators for correct/wrong answers
- **Smooth Animations**: Enhanced user experience with transitions

## App Flow

1. **Splash Screen** → Shows app logo for 2 seconds
2. **Main Menu** → Choose from 6 quiz categories
3. **Quiz Screen** → Answer 10 questions with timer
4. **Result Screen** → View score and options to play again

## Technical Implementation

### Activities
- `SplashActivity`: App launch screen
- `MainActivity`: Category selection menu
- `QuizActivity`: Question display and answer handling
- `ResultActivity`: Score display and navigation

### Key Classes
- `Question`: Model class for quiz questions
- `QuestionBank`: Static class containing all quiz questions
- `SharedPreferences`: High score persistence

### Features Implemented
- ✅ 6 categories with 10 questions each
- ✅ Multiple choice questions (4 options each)
- ✅ Timer functionality (20 seconds per question)
- ✅ Question shuffling
- ✅ High score tracking
- ✅ Progress indicators
- ✅ Clean UI with Material Design
- ✅ Result calculation and display

## Getting Started

1. Open the project in Android Studio
2. Sync the project with Gradle files
3. Run the app on an Android device or emulator
4. Select a category and start quizzing!

## Requirements

- Android API Level 21+ (Android 5.0)
- Java 8+
- Android Studio 4.0+

## Categories & Questions

### Science (10 questions)
- Chemistry, Physics, Biology topics
- Questions about elements, planets, scientific principles

### History (10 questions)
- World history, important events, historical figures
- Questions about wars, discoveries, civilizations

### Sports (10 questions)
- Various sports rules, famous athletes, tournaments
- Questions about Olympics, World Cup, sports terminology

### Technology (10 questions)
- Computer science, programming, tech companies
- Questions about software, hardware, internet

### General Knowledge (10 questions)
- Geography, capitals, countries, facts
- Questions about world records, famous places

### Movies (10 questions)
- Film industry, directors, actors, movie facts
- Questions about famous movies, awards, quotes

## Scoring System

- **Correct Answer**: +1 point
- **Wrong Answer**: 0 points
- **Time Up**: 0 points (counted as wrong)
- **Final Score**: Percentage based on correct answers
- **High Score**: Best score across all attempts

## Performance Feedback

- **90%+**: "Excellent!"
- **70-89%**: "Good Job!"
- **50-69%**: "Not Bad!"
- **<50%**: "Keep Practicing!"

Enjoy testing your knowledge with Quiz Master! 🧠✨
