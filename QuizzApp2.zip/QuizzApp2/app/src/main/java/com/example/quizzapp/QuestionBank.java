package com.example.quizzapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class QuestionBank {
    private static final String SCIENCE = "Science";
    private static final String HISTORY = "History";
    private static final String SPORTS = "Sports";
    private static final String TECHNOLOGY = "Technology";
    private static final String GK = "General Knowledge";
    private static final String MOVIES = "Movies";

    public static List<Question> getScienceQuestions() {
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("What is the chemical symbol for water?", "H2O", "CO2", "NaCl", "O2", 1));
        questions.add(new Question("Which planet is known as the Red Planet?", "Venus", "Mars", "Jupiter", "Saturn", 2));
        questions.add(new Question("What is the speed of light in vacuum?", "300,000 km/s", "150,000 km/s", "450,000 km/s", "600,000 km/s", 1));
        questions.add(new Question("Who discovered gravity?", "Isaac Newton", "Albert Einstein", "Galileo Galilei", "Charles Darwin", 1));
        questions.add(new Question("What is the smallest unit of matter?", "Atom", "Molecule", "Cell", "Electron", 1));
        questions.add(new Question("Which gas makes up most of Earth's atmosphere?", "Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen", 2));
        questions.add(new Question("What is the process by which plants make food?", "Respiration", "Photosynthesis", "Digestion", "Fermentation", 2));
        questions.add(new Question("Which blood type is known as the universal donor?", "A", "B", "AB", "O", 4));
        questions.add(new Question("What is the hardest natural substance?", "Gold", "Diamond", "Iron", "Silver", 2));
        questions.add(new Question("Which organ produces insulin?", "Liver", "Pancreas", "Kidney", "Heart", 2));
        return questions;
    }

    public static List<Question> getHistoryQuestions() {
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("In which year did World War II end?", "1944", "1945", "1946", "1947", 2));
        questions.add(new Question("Who was the first President of the United States?", "Thomas Jefferson", "George Washington", "John Adams", "Benjamin Franklin", 2));
        questions.add(new Question("Which ancient wonder was located in Egypt?", "Hanging Gardens", "Colossus of Rhodes", "Great Pyramid of Giza", "Temple of Artemis", 3));
        questions.add(new Question("In which year did the Berlin Wall fall?", "1987", "1988", "1989", "1990", 3));
        questions.add(new Question("Who wrote the Declaration of Independence?", "George Washington", "Thomas Jefferson", "Benjamin Franklin", "John Adams", 2));
        questions.add(new Question("Which empire was ruled by Julius Caesar?", "Greek Empire", "Roman Empire", "Byzantine Empire", "Ottoman Empire", 2));
        questions.add(new Question("In which year did the Titanic sink?", "1910", "1911", "1912", "1913", 3));
        questions.add(new Question("Who was the first person to walk on the moon?", "Neil Armstrong", "Buzz Aldrin", "John Glenn", "Yuri Gagarin", 1));
        questions.add(new Question("Which war was fought between 1861-1865?", "Revolutionary War", "Civil War", "World War I", "World War II", 2));
        questions.add(new Question("Who painted the Mona Lisa?", "Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo", 3));
        return questions;
    }

    public static List<Question> getSportsQuestions() {
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("How many players are on a basketball team?", "4", "5", "6", "7", 2));
        questions.add(new Question("Which sport is played at Wimbledon?", "Tennis", "Golf", "Cricket", "Football", 1));
        questions.add(new Question("How many rings are in the Olympic symbol?", "4", "5", "6", "7", 2));
        questions.add(new Question("Which country won the FIFA World Cup in 2018?", "Brazil", "Germany", "France", "Argentina", 3));
        questions.add(new Question("In which sport would you perform a slam dunk?", "Volleyball", "Basketball", "Tennis", "Badminton", 2));
        questions.add(new Question("How many innings are in a standard baseball game?", "7", "8", "9", "10", 3));
        questions.add(new Question("Which sport uses a shuttlecock?", "Tennis", "Badminton", "Squash", "Table Tennis", 2));
        questions.add(new Question("How many players are on a football team?", "10", "11", "12", "13", 2));
        questions.add(new Question("Which sport is known as 'the beautiful game'?", "Basketball", "Football", "Tennis", "Golf", 2));
        questions.add(new Question("In which year were the first modern Olympics held?", "1894", "1896", "1900", "1904", 2));
        return questions;
    }

    public static List<Question> getTechnologyQuestions() {
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("What does CPU stand for?", "Central Processing Unit", "Computer Processing Unit", "Central Program Unit", "Computer Program Unit", 1));
        questions.add(new Question("Which company developed the Android operating system?", "Apple", "Microsoft", "Google", "Samsung", 3));
        questions.add(new Question("What does HTML stand for?", "HyperText Markup Language", "High Tech Modern Language", "Home Tool Markup Language", "Hyperlink and Text Markup Language", 1));
        questions.add(new Question("Which programming language was created by James Gosling?", "C++", "Python", "Java", "JavaScript", 3));
        questions.add(new Question("What does RAM stand for?", "Random Access Memory", "Read Access Memory", "Rapid Access Memory", "Real Access Memory", 1));
        questions.add(new Question("Which company created the iPhone?", "Samsung", "Google", "Apple", "Microsoft", 3));
        questions.add(new Question("What does URL stand for?", "Uniform Resource Locator", "Universal Resource Locator", "Uniform Reference Locator", "Universal Reference Locator", 1));
        questions.add(new Question("Which year was the first iPhone released?", "2005", "2006", "2007", "2008", 3));
        questions.add(new Question("What does AI stand for?", "Automated Intelligence", "Artificial Intelligence", "Advanced Intelligence", "Automatic Intelligence", 2));
        questions.add(new Question("Which company owns YouTube?", "Google", "Facebook", "Microsoft", "Apple", 1));
        return questions;
    }

    public static List<Question> getGKQuestions() {
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("What is the capital of Australia?", "Sydney", "Melbourne", "Canberra", "Perth", 3));
        questions.add(new Question("Which is the largest ocean?", "Atlantic", "Pacific", "Indian", "Arctic", 2));
        questions.add(new Question("How many continents are there?", "5", "6", "7", "8", 3));
        questions.add(new Question("What is the currency of Japan?", "Won", "Yuan", "Yen", "Dollar", 3));
        questions.add(new Question("Which is the smallest country in the world?", "Monaco", "Vatican City", "Liechtenstein", "San Marino", 2));
        questions.add(new Question("What is the longest river in the world?", "Amazon", "Nile", "Mississippi", "Yangtze", 2));
        questions.add(new Question("Which is the highest mountain in the world?", "K2", "Mount Everest", "Kangchenjunga", "Lhotse", 2));
        questions.add(new Question("What is the largest desert in the world?", "Gobi", "Sahara", "Arabian", "Antarctic", 4));
        questions.add(new Question("Which country has the most population?", "India", "China", "United States", "Indonesia", 2));
        questions.add(new Question("What is the national animal of India?", "Lion", "Tiger", "Elephant", "Peacock", 2));
        return questions;
    }

    public static List<Question> getMoviesQuestions() {
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("Who directed the movie 'Inception'?", "Christopher Nolan", "Steven Spielberg", "Martin Scorsese", "Quentin Tarantino", 1));
        questions.add(new Question("Which movie won the Academy Award for Best Picture in 2020?", "Joker", "1917", "Parasite", "Once Upon a Time in Hollywood", 3));
        questions.add(new Question("Who played Jack in 'Titanic'?", "Brad Pitt", "Leonardo DiCaprio", "Tom Cruise", "Johnny Depp", 2));
        questions.add(new Question("Which movie series features the character Harry Potter?", "Lord of the Rings", "Harry Potter", "Star Wars", "The Hunger Games", 2));
        questions.add(new Question("Who composed the music for 'The Lion King'?", "John Williams", "Hans Zimmer", "Alan Menken", "Elton John", 3));
        questions.add(new Question("Which movie is based on the novel by Stephen King?", "The Shining", "Jaws", "Alien", "The Exorcist", 1));
        questions.add(new Question("Who directed 'Pulp Fiction'?", "Martin Scorsese", "Quentin Tarantino", "David Fincher", "Christopher Nolan", 2));
        questions.add(new Question("Which movie features the quote 'May the Force be with you'?", "Star Trek", "Star Wars", "Blade Runner", "The Matrix", 2));
        questions.add(new Question("Who played the Joker in 'The Dark Knight'?", "Jack Nicholson", "Heath Ledger", "Joaquin Phoenix", "Jared Leto", 2));
        questions.add(new Question("Which movie won the most Academy Awards?", "Titanic", "Ben-Hur", "The Lord of the Rings: The Return of the King", "La La Land", 3));
        return questions;
    }

    public static List<Question> getQuestionsForCategory(String category) {
        switch (category) {
            case SCIENCE:
                return getScienceQuestions();
            case HISTORY:
                return getHistoryQuestions();
            case SPORTS:
                return getSportsQuestions();
            case TECHNOLOGY:
                return getTechnologyQuestions();
            case GK:
                return getGKQuestions();
            case MOVIES:
                return getMoviesQuestions();
            default:
                return new ArrayList<>();
        }
    }

    public static List<Question> getShuffledQuestionsForCategory(String category) {
        List<Question> questions = getQuestionsForCategory(category);
        Collections.shuffle(questions);
        return questions;
    }

    public static String[] getCategories() {
        return new String[]{SCIENCE, HISTORY, SPORTS, TECHNOLOGY, GK, MOVIES};
    }
}
