package com.example.quizzapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvCategory, tvScore, tvCorrect, tvWrong, tvPercentage, tvMessage, tvNewHighScore;
    private Button btnPlayAgain, btnMainMenu;
    
    private String category;
    private int correctAnswers, wrongAnswers, totalQuestions;
    private double percentage;
    private boolean isNewHighScore = false;
    
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "QuizPrefs";
    private static final String KEY_HIGH_SCORE = "high_score";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        initializeViews();
        setupClickListeners();
        loadResultData();
        calculateResults();
        displayResults();
        checkHighScore();
    }

    private void initializeViews() {
        tvCategory = findViewById(R.id.tv_category);
        tvScore = findViewById(R.id.tv_score);
        tvCorrect = findViewById(R.id.tv_correct);
        tvWrong = findViewById(R.id.tv_wrong);
        tvPercentage = findViewById(R.id.tv_percentage);
        tvMessage = findViewById(R.id.tv_message);
        tvNewHighScore = findViewById(R.id.tv_new_high_score);
        btnPlayAgain = findViewById(R.id.btn_play_again);
        btnMainMenu = findViewById(R.id.btn_main_menu);
    }

    private void setupClickListeners() {
        btnPlayAgain.setOnClickListener(this);
        btnMainMenu.setOnClickListener(this);
    }

    private void loadResultData() {
        Intent intent = getIntent();
        category = intent.getStringExtra("category");
        correctAnswers = intent.getIntExtra("correct_answers", 0);
        wrongAnswers = intent.getIntExtra("wrong_answers", 0);
        totalQuestions = intent.getIntExtra("total_questions", 0);
        
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }

    private void calculateResults() {
        percentage = (double) correctAnswers / totalQuestions * 100;
    }

    private void displayResults() {
        tvCategory.setText(category);
        tvCorrect.setText(getString(R.string.correct_answers, correctAnswers));
        tvWrong.setText(getString(R.string.wrong_answers, wrongAnswers));
        tvPercentage.setText(getString(R.string.percentage, percentage));
        
        // Set performance message
        String message;
        if (percentage >= 90) {
            message = getString(R.string.excellent);
        } else if (percentage >= 70) {
            message = getString(R.string.good);
        } else if (percentage >= 50) {
            message = getString(R.string.average);
        } else {
            message = getString(R.string.needs_improvement);
        }
        tvMessage.setText(message);
    }

    private void checkHighScore() {
        int currentHighScore = sharedPreferences.getInt(KEY_HIGH_SCORE, 0);
        
        if (correctAnswers > currentHighScore) {
            isNewHighScore = true;
            tvNewHighScore.setVisibility(View.VISIBLE);
            
            // Save new high score
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt(KEY_HIGH_SCORE, correctAnswers);
            editor.apply();
        } else {
            tvNewHighScore.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        int buttonId = v.getId();
        
        if (buttonId == R.id.btn_play_again) {
            // Play the same category again
            Intent intent = new Intent(this, QuizActivity.class);
            intent.putExtra("category", category);
            startActivity(intent);
            finish();
        } else if (buttonId == R.id.btn_main_menu) {
            // Go back to main menu
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        // Go back to main menu when back button is pressed
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}
