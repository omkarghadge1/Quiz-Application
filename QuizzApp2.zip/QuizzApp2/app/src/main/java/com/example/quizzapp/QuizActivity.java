package com.example.quizzapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class QuizActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvQuestion, tvProgress, tvTimer, tvCategory;
    private RadioGroup radioGroup;
    private RadioButton rbOptionA, rbOptionB, rbOptionC, rbOptionD;
    private Button btnNext;
    private ProgressBar progressBar;

    private List<Question> questions;
    private int currentQuestionIndex = 0;
    private int correctAnswers = 0;
    private int wrongAnswers = 0;
    private String category;
    private CountDownTimer timer;
    private static final int QUESTION_TIME_LIMIT = 20000; // 20 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        initializeViews();
        setupClickListeners();
        loadQuizData();
        displayQuestion();
    }

    private void initializeViews() {
        tvQuestion = findViewById(R.id.tv_question);
        tvProgress = findViewById(R.id.tv_progress);
        tvTimer = findViewById(R.id.tv_timer);
        tvCategory = findViewById(R.id.tv_category);
        radioGroup = findViewById(R.id.radio_group);
        rbOptionA = findViewById(R.id.rb_option_a);
        rbOptionB = findViewById(R.id.rb_option_b);
        rbOptionC = findViewById(R.id.rb_option_c);
        rbOptionD = findViewById(R.id.rb_option_d);
        btnNext = findViewById(R.id.btn_next);
        progressBar = findViewById(R.id.progress_bar);
    }

    private void setupClickListeners() {
        btnNext.setOnClickListener(this);
    }

    private void loadQuizData() {
        category = getIntent().getStringExtra("category");
        tvCategory.setText(category);
        questions = QuestionBank.getShuffledQuestionsForCategory(category);
        progressBar.setMax(questions.size());
    }

    private void displayQuestion() {
        if (currentQuestionIndex < questions.size()) {
            Question currentQuestion = questions.get(currentQuestionIndex);
            
            tvQuestion.setText(currentQuestion.getQuestion());
            rbOptionA.setText(currentQuestion.getOptionA());
            rbOptionB.setText(currentQuestion.getOptionB());
            rbOptionC.setText(currentQuestion.getOptionC());
            rbOptionD.setText(currentQuestion.getOptionD());
            
            radioGroup.clearCheck();
            
            tvProgress.setText(getString(R.string.question_progress, currentQuestionIndex + 1, questions.size()));
            progressBar.setProgress(currentQuestionIndex + 1);
            
            if (currentQuestionIndex == questions.size() - 1) {
                btnNext.setText(getString(R.string.submit_quiz));
            } else {
                btnNext.setText(getString(R.string.next_question));
            }
            
            startTimer();
        }
    }

    private void startTimer() {
        if (timer != null) {
            timer.cancel();
        }
        
        timer = new CountDownTimer(QUESTION_TIME_LIMIT, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int seconds = (int) (millisUntilFinished / 1000);
                tvTimer.setText(getString(R.string.time_remaining, seconds));
            }

            @Override
            public void onFinish() {
                tvTimer.setText(getString(R.string.time_up));
                handleTimeUp();
            }
        }.start();
    }

    private void handleTimeUp() {
        wrongAnswers++;
        moveToNextQuestion();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_next) {
            handleNextButton();
        }
    }

    private void handleNextButton() {
        int selectedId = radioGroup.getCheckedRadioButtonId();
        
        if (selectedId == -1) {
            Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (timer != null) {
            timer.cancel();
        }
        
        checkAnswer(selectedId);
        moveToNextQuestion();
    }

    private void checkAnswer(int selectedId) {
        Question currentQuestion = questions.get(currentQuestionIndex);
        int selectedAnswer = -1;
        
        if (selectedId == R.id.rb_option_a) {
            selectedAnswer = 1;
        } else if (selectedId == R.id.rb_option_b) {
            selectedAnswer = 2;
        } else if (selectedId == R.id.rb_option_c) {
            selectedAnswer = 3;
        } else if (selectedId == R.id.rb_option_d) {
            selectedAnswer = 4;
        }
        
        if (selectedAnswer == currentQuestion.getCorrectAnswer()) {
            correctAnswers++;
        } else {
            wrongAnswers++;
        }
    }

    private void moveToNextQuestion() {
        currentQuestionIndex++;
        
        if (currentQuestionIndex < questions.size()) {
            displayQuestion();
        } else {
            finishQuiz();
        }
    }

    private void finishQuiz() {
        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("category", category);
        intent.putExtra("correct_answers", correctAnswers);
        intent.putExtra("wrong_answers", wrongAnswers);
        intent.putExtra("total_questions", questions.size());
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) {
            timer.cancel();
        }
    }

    @Override
    public void onBackPressed() {
        if (timer != null) {
            timer.cancel();
        }
        super.onBackPressed();
    }
}
