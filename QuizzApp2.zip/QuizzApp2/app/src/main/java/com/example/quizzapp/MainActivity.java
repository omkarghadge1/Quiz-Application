package com.example.quizzapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvHighScore;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "QuizPrefs";
    private static final String KEY_HIGH_SCORE = "high_score";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupClickListeners();
        loadHighScore();
    }

    private void initializeViews() {
        tvHighScore = findViewById(R.id.tv_high_score);
    }

    private void setupClickListeners() {
        findViewById(R.id.btn_science).setOnClickListener(this);
        findViewById(R.id.btn_history).setOnClickListener(this);
        findViewById(R.id.btn_sports).setOnClickListener(this);
        findViewById(R.id.btn_technology).setOnClickListener(this);
        findViewById(R.id.btn_gk).setOnClickListener(this);
        findViewById(R.id.btn_movies).setOnClickListener(this);
    }

    private void loadHighScore() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int highScore = sharedPreferences.getInt(KEY_HIGH_SCORE, 0);
        tvHighScore.setText(getString(R.string.high_score, highScore));
    }

    @Override
    public void onClick(View v) {
        String category = "";
        int buttonId = v.getId();

        if (buttonId == R.id.btn_science) {
            category = "Science";
        } else if (buttonId == R.id.btn_history) {
            category = "History";
        } else if (buttonId == R.id.btn_sports) {
            category = "Sports";
        } else if (buttonId == R.id.btn_technology) {
            category = "Technology";
        } else if (buttonId == R.id.btn_gk) {
            category = "General Knowledge";
        } else if (buttonId == R.id.btn_movies) {
            category = "Movies";
        }

        if (!category.isEmpty()) {
            Intent intent = new Intent(this, QuizActivity.class);
            intent.putExtra("category", category);
            startActivity(intent);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHighScore();
    }
}